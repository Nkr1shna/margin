archives are invisible to folder sync
